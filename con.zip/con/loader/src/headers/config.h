#pragma once

#define HTTP_SERVER "192.46.230.56"
#define HTTP_PORT 80

#define TFTP_SERVER "192.46.230.56"
